import { ChevronRight, Users, TrendingUp, CheckCircle, Code2, Zap, BarChart3, Package } from 'lucide-react';

const Index = () => {
  return (
    <div className="w-full bg-background">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur border-b border-border">
        <div className="section-container flex items-center justify-between py-4">
          <div className="text-xl font-serif font-bold text-primary">E-Commerce Expert</div>
          <div className="hidden md:flex gap-8 text-sm font-medium">
            <a href="#approach" className="hover:text-primary transition-colors">Approach</a>
            <a href="#services" className="hover:text-primary transition-colors">Services</a>
            <a href="#platforms" className="hover:text-primary transition-colors">Platforms</a>
            <a href="#portfolio" className="hover:text-primary transition-colors">Portfolio</a>
            <a href="#process" className="hover:text-primary transition-colors">Process</a>
          </div>
          <button className="btn-primary text-sm">Get Started</button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative bg-gradient-to-b from-background to-background/80 py-20 md:py-32 overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 right-20 w-96 h-96 bg-primary rounded-full blur-3xl"></div>
        </div>
        
        <div className="section-container relative z-10 text-center">
          <h1 className="text-primary mb-6 leading-tight">
            Shopify & Multi-Platform<br />E-Commerce Expert
          </h1>
          
          <p className="text-lg md:text-xl text-foreground/80 max-w-2xl mx-auto mb-12 leading-relaxed">
            Transforming chaotic e-commerce tasks into seamless, efficient operations. With 8+ years in corporate administration and specialized e-commerce expertise, I deliver precise data management and organized systems across Shopify, eBay, Poshmark, and WooCommerce.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <button className="btn-primary">Let's Optimize Your Store</button>
            <button className="btn-secondary">Learn More</button>
          </div>
        </div>
      </section>

      {/* Corporate Precision Section */}
      <section className="py-20 md:py-32 bg-secondary/20">
        <div className="section-container grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-primary mb-6">Corporate Precision Meets E-Commerce Innovation</h2>
            
            <p className="text-foreground/70 mb-6 leading-relaxed">
              My background in corporate data management, process development, and customer service coordination means I don't just complete tasks—I create systems that make your entire operation more efficient.
            </p>
            
            <p className="text-foreground/70 leading-relaxed">
              I've managed complex corporate databases and coordinated multi-department workflows. Now I apply those same professional standards to helping online sellers build, optimize, and manage their stores.
            </p>
          </div>
          
          <div className="bg-secondary rounded-lg p-8 border border-border">
            <h3 className="text-primary text-2xl font-serif mb-4">My Mission</h3>
            <p className="text-foreground/70 leading-relaxed">
              To become a trusted operational partner who understands your business deeply enough to anticipate needs and propose improvements, freeing you to innovate and expand.
            </p>
          </div>
        </div>
      </section>

      {/* Approach Section */}
      <section id="approach" className="py-20 md:py-32 bg-background">
        <div className="section-container">
          <h2 className="text-primary text-center mb-16">My Approach to E-Commerce Excellence</h2>
          
          <div className="grid md:grid-cols-2 gap-8">
            {/* Accuracy First */}
            <div className="bg-secondary rounded-lg p-8 border border-border hover:border-primary/50 transition-colors">
              <div className="flex items-start gap-4 mb-4">
                <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                  <CheckCircle className="text-primary" size={24} />
                </div>
                <h3 className="text-primary text-2xl font-serif">Accuracy First</h3>
              </div>
              <p className="text-foreground/70">
                Treating every product listing, inventory count, and data entry task with the precision of a financial report. Errors in e-commerce cost real money—I make sure the details are right.
              </p>
            </div>

            {/* Process-Driven */}
            <div className="bg-secondary rounded-lg p-8 border border-border hover:border-primary/50 transition-colors">
              <div className="flex items-start gap-4 mb-4">
                <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                  <Zap className="text-primary" size={24} />
                </div>
                <h3 className="text-primary text-2xl font-serif">Process-Driven</h3>
              </div>
              <p className="text-foreground/70">
                Creating custom systems and SOPs for every client engagement, ensuring tasks are documented, repeatable, and scalable. Consistent results whether managing 50 or 5,000 products.
              </p>
            </div>

            {/* Clear Communication */}
            <div className="bg-secondary rounded-lg p-8 border border-border hover:border-primary/50 transition-colors">
              <div className="flex items-start gap-4 mb-4">
                <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                  <Users className="text-primary" size={24} />
                </div>
                <h3 className="text-primary text-2xl font-serif">Clear Communication</h3>
              </div>
              <p className="text-foreground/70">
                Responsive, professional communication from BPO experience. You'll always know project status, and I'll flag potential issues before they become problems.
              </p>
            </div>

            {/* Continuous Improvement */}
            <div className="bg-secondary rounded-lg p-8 border border-border hover:border-primary/50 transition-colors">
              <div className="flex items-start gap-4 mb-4">
                <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                  <TrendingUp className="text-primary" size={24} />
                </div>
                <h3 className="text-primary text-2xl font-serif">Continuous Improvement</h3>
              </div>
              <p className="text-foreground/70">
                Actively tracking platform changes, algorithm updates, and industry best practices. Your store benefits from current strategies, not outdated approaches.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 md:py-32 bg-secondary/20">
        <div className="section-container">
          <h2 className="text-primary text-center mb-4">Comprehensive E-Commerce Support Services</h2>
          <p className="text-center text-foreground/70 mb-16 max-w-2xl mx-auto">
            Handling the operational complexity of multi-platform selling, allowing you to focus on strategic business growth.
          </p>
          
          <div className="grid md:grid-cols-3 gap-8">
            {/* Product Listing */}
            <div className="bg-background rounded-lg overflow-hidden border border-border hover:border-primary/50 transition-colors">
              <div className="h-40 bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center">
                <Package className="text-primary" size={48} />
              </div>
              <div className="p-6">
                <h3 className="text-primary font-serif text-xl mb-3">Product Listing & Optimization</h3>
                <p className="text-foreground/70 text-sm">
                  SEO-optimized titles, compelling descriptions, strategic keyword placement, and cross-platform adaptation that actively sells.
                </p>
              </div>
            </div>

            {/* Inventory Management */}
            <div className="bg-background rounded-lg overflow-hidden border border-border hover:border-primary/50 transition-colors">
              <div className="h-40 bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center">
                <BarChart3 className="text-primary" size={48} />
              </div>
              <div className="p-6">
                <h3 className="text-primary font-serif text-xl mb-3">Inventory Management</h3>
                <p className="text-foreground/70 text-sm">
                  Systematic tracking preventing overselling or stockouts. Multi-platform synchronization, stock alerts, and performance reporting.
                </p>
              </div>
            </div>

            {/* Customer Support */}
            <div className="bg-background rounded-lg overflow-hidden border border-border hover:border-primary/50 transition-colors">
              <div className="h-40 bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center">
                <Users className="text-primary" size={48} />
              </div>
              <div className="p-6">
                <h3 className="text-primary font-serif text-xl mb-3">Customer Support</h3>
                <p className="text-foreground/70 text-sm">
                  Responsive, professional communication protecting your brand reputation and building customer loyalty through problem-solving.
                </p>
              </div>
            </div>

            {/* Store Administration */}
            <div className="bg-background rounded-lg overflow-hidden border border-border hover:border-primary/50 transition-colors">
              <div className="h-40 bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center">
                <Code2 className="text-primary" size={48} />
              </div>
              <div className="p-6">
                <h3 className="text-primary font-serif text-xl mb-3">Store Administration</h3>
                <p className="text-foreground/70 text-sm">
                  Daily order processing, shipping management, return handling, policy updates, and platform compliance maintenance.
                </p>
              </div>
            </div>

            {/* Data Entry & Research */}
            <div className="bg-background rounded-lg overflow-hidden border border-border hover:border-primary/50 transition-colors">
              <div className="h-40 bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center">
                <CheckCircle className="text-primary" size={48} />
              </div>
              <div className="p-6">
                <h3 className="text-primary font-serif text-xl mb-3">Data Entry & Research</h3>
                <p className="text-foreground/70 text-sm">
                  Bulk product data entry, competitor price monitoring, market trend research, and sales data analysis for informed decisions.
                </p>
              </div>
            </div>

            {/* Analytics & Optimization */}
            <div className="bg-background rounded-lg overflow-hidden border border-border hover:border-primary/50 transition-colors">
              <div className="h-40 bg-gradient-to-br from-primary/20 to-primary/10 flex items-center justify-center">
                <TrendingUp className="text-primary" size={48} />
              </div>
              <div className="p-6">
                <h3 className="text-primary font-serif text-xl mb-3">Analytics & Optimization</h3>
                <p className="text-foreground/70 text-sm">
                  Performance tracking, conversion rate analysis, and strategic recommendations to continuously improve your store's growth.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Multi-Platform Expertise */}
      <section id="platforms" className="py-20 md:py-32 bg-background">
        <div className="section-container">
          <h2 className="text-primary text-center mb-16">Multi-Platform Expertise</h2>
          
          <div className="grid md:grid-cols-2 gap-8">
            {/* Shopify */}
            <div className="bg-secondary rounded-lg p-8 border border-border hover:border-primary/50 transition-colors">
              <h3 className="text-primary font-serif text-2xl mb-4">Shopify</h3>
              <p className="text-foreground/70">
                Complete store setup, theme customization, product management, app integration, SEO tools, analytics, and inventory features.
              </p>
            </div>

            {/* eBay */}
            <div className="bg-secondary rounded-lg p-8 border border-border hover:border-primary/50 transition-colors">
              <h3 className="text-primary font-serif text-2xl mb-4">eBay</h3>
              <p className="text-foreground/70">
                Listing optimization, auction management, eBay SEO, seller performance monitoring, and algorithm best practices.
              </p>
            </div>

            {/* Poshmark */}
            <div className="bg-secondary rounded-lg p-8 border border-border hover:border-primary/50 transition-colors">
              <h3 className="text-primary font-serif text-2xl mb-4">Poshmark</h3>
              <p className="text-foreground/70">
                Closet management, sharing strategies, listing optimization, and community engagement with social selling features.
              </p>
            </div>

            {/* WooCommerce */}
            <div className="bg-secondary rounded-lg p-8 border border-border hover:border-primary/50 transition-colors">
              <h3 className="text-primary font-serif text-2xl mb-4">WooCommerce</h3>
              <p className="text-foreground/70">
                WordPress-based store management, plugin configuration, and product catalog maintenance for seamless operations.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Technical Skills Section */}
      <section className="py-20 md:py-32 bg-secondary/20">
        <div className="section-container">
          <h2 className="text-primary text-center mb-16">Technical Skills & Core Competencies</h2>
          
          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <h3 className="text-primary font-serif text-2xl mb-6">Technical Tools</h3>
              <ul className="space-y-3 text-foreground/70">
                <li className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  Microsoft Office Suite (Excel, Word, PowerPoint)
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  Google Workspace (Sheets, Docs, Drive)
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  Communication platforms (Slack, Zoom, Teams)
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  Canva for product images
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  Google Analytics basics
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  SEO research tools
                </li>
              </ul>
            </div>

            <div>
              <h3 className="text-primary font-serif text-2xl mb-6">Core Strengths</h3>
              <ul className="space-y-3 text-foreground/70">
                <li className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  Data Entry & Database Management
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  Process Development & Documentation
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  Multi-Platform Coordination
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  Customer Relationship Management
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  Time Management & Prioritization
                </li>
                <li className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-primary rounded-full"></div>
                  Quality Assurance
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      <section id="portfolio" className="py-20 md:py-32 bg-background">
        <div className="section-container">
          <h2 className="text-primary text-center mb-4">Work Samples & Portfolio</h2>
          <p className="text-center text-foreground/70 mb-16 max-w-2xl mx-auto">
            Demonstrating quality, attention to detail, and strategic thinking across product categories and operational tasks.
          </p>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="rounded-lg overflow-hidden border border-border hover:border-primary/50 transition-colors group">
              <div className="h-48 bg-gradient-to-br from-purple-900 to-pink-900 flex items-center justify-center relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-r from-purple-500/20 to-pink-500/20"></div>
              </div>
              <div className="p-6">
                <h3 className="text-primary font-serif text-xl mb-3">Fashion: Leather Crossbody Bag</h3>
                <p className="text-foreground/70 text-sm">
                  SEO-optimized title with key search terms, benefit-focused description, strategic keyword placement, and detailed specifications.
                </p>
              </div>
            </div>

            <div className="rounded-lg overflow-hidden border border-border hover:border-primary/50 transition-colors group">
              <div className="h-48 bg-gradient-to-br from-orange-900 to-red-900 flex items-center justify-center relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-r from-orange-500/20 to-red-500/20"></div>
              </div>
              <div className="p-6">
                <h3 className="text-primary font-serif text-xl mb-3">Electronics: Wireless Headphones</h3>
                <p className="text-foreground/70 text-sm">
                  Technical specs listed for comparison shoppers, feature-benefit pairing in description, and competitive positioning.
                </p>
              </div>
            </div>

            <div className="rounded-lg overflow-hidden border border-border hover:border-primary/50 transition-colors group">
              <div className="h-48 bg-gradient-to-br from-yellow-900 to-orange-900 flex items-center justify-center relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-r from-yellow-500/20 to-orange-500/20"></div>
              </div>
              <div className="p-6">
                <h3 className="text-primary font-serif text-xl mb-3">Home: Bamboo Desk Organizer</h3>
                <p className="text-foreground/70 text-sm">
                  Sustainability angle in product positioning, lifestyle-focused description, and natural finish complementing any decor.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* What Sets Apart Section */}
      <section className="py-20 md:py-32 bg-secondary/20">
        <div className="section-container">
          <h2 className="text-primary text-center mb-16">What Sets Me Apart</h2>
          
          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <div className="bg-background rounded-lg p-8 border border-border">
              <h3 className="text-primary font-serif text-2xl mb-4">Corporate-Grade Professionalism</h3>
              <p className="text-foreground/70">
                8+ years in corporate environments means enterprise-level work ethic at virtual assistant rates. Understanding deadlines, confidentiality, and getting it right the first time.
              </p>
            </div>

            <div className="bg-background rounded-lg p-8 border border-border">
              <h3 className="text-primary font-serif text-2xl mb-4">Data Precision</h3>
              <p className="text-foreground/70">
                Zero-tolerance approach to errors from managing corporate databases where mistakes had significant consequences. Applied to your product data, inventory, and financial tracking.
              </p>
            </div>

            <div className="bg-background rounded-lg p-8 border border-border">
              <h3 className="text-primary font-serif text-2xl mb-4">Growth-Oriented Mindset</h3>
              <p className="text-foreground/70">
                Don't just maintain operations—I actively look for improvements, optimizations, and growth opportunities. Every task makes your business better.
              </p>
            </div>
          </div>

          <div className="bg-background rounded-lg p-8 border-l-4 border-primary">
            <p className="text-lg text-foreground italic">
              "I pledge to meet every deadline, maintain open communication, and treat your business with the same care and attention I would give my own. Your success is my professional reputation."
            </p>
          </div>
        </div>
      </section>

      {/* How We Work Together Section */}
      <section id="process" className="py-20 md:py-32 bg-background">
        <div className="section-container">
          <h2 className="text-primary text-center mb-4">How We Work Together</h2>
          <p className="text-center text-foreground/70 mb-16 max-w-2xl mx-auto">
            Clear processes and transparent communication ensure you always know where things stand.
          </p>
          
          <div className="max-w-3xl mx-auto space-y-6">
            {/* Step 1 */}
            <div className="flex gap-6 items-start">
              <div className="flex-shrink-0 w-12 h-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-serif font-bold text-lg">
                1
              </div>
              <div className="flex-grow">
                <h3 className="text-primary font-serif text-xl mb-2">Discovery Call</h3>
                <p className="text-foreground/70">
                  Free consultation to understand your business, challenges, platforms, and goals. Creating a tailored support plan.
                </p>
              </div>
            </div>

            {/* Step 2 */}
            <div className="flex gap-6 items-start">
              <div className="flex-shrink-0 w-12 h-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-serif font-bold text-lg">
                2
              </div>
              <div className="flex-grow">
                <h3 className="text-primary font-serif text-xl mb-2">Needs Assessment</h3>
                <p className="text-foreground/70">
                  Audit current operations, identify inefficiencies, document improvements. Receive detailed report with recommendations.
                </p>
              </div>
            </div>

            {/* Step 3 */}
            <div className="flex gap-6 items-start">
              <div className="flex-shrink-0 w-12 h-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-serif font-bold text-lg">
                3
              </div>
              <div className="flex-grow">
                <h3 className="text-primary font-serif text-xl mb-2">Custom Plan Development</h3>
                <p className="text-foreground/70">
                  Structured work plan with clear deliverables, timelines, and communication schedules for predictable results.
                </p>
              </div>
            </div>

            {/* Step 4 */}
            <div className="flex gap-6 items-start">
              <div className="flex-shrink-0 w-12 h-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-serif font-bold text-lg">
                4
              </div>
              <div className="flex-grow">
                <h3 className="text-primary font-serif text-xl mb-2">Systematic Implementation</h3>
                <p className="text-foreground/70">
                  Execute plan methodically, starting with quick wins building toward larger optimizations. Regular progress updates.
                </p>
              </div>
            </div>

            {/* Step 5 */}
            <div className="flex gap-6 items-start">
              <div className="flex-shrink-0 w-12 h-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-serif font-bold text-lg">
                5
              </div>
              <div className="flex-grow">
                <h3 className="text-primary font-serif text-xl mb-2">Quality Review</h3>
                <p className="text-foreground/70">
                  Every deliverable goes through systematic quality check before submission. Verify accuracy and brand alignment.
                </p>
              </div>
            </div>

            {/* Step 6 */}
            <div className="flex gap-6 items-start">
              <div className="flex-shrink-0 w-12 h-12 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-serif font-bold text-lg">
                6
              </div>
              <div className="flex-grow">
                <h3 className="text-primary font-serif text-xl mb-2">Ongoing Optimization</h3>
                <p className="text-foreground/70">
                  Continuously monitor metrics, track platform changes, propose improvements. Operations improve over time.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="py-20 md:py-32 bg-secondary/20">
        <div className="section-container">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-primary mb-8">Ready to Optimize Your Store?</h2>
              
              <p className="text-foreground/70 mb-8">
                With limited spots available for new clients, I ensure every partnership receives my full attention and commitment. Let's discuss how I can support your e-commerce growth.
              </p>

              <h3 className="text-primary font-serif text-2xl mb-6">Flexible Packages</h3>
              
              <div className="space-y-6 mb-8">
                <div>
                  <h4 className="text-white font-semibold mb-2">Starter</h4>
                  <p className="text-foreground/70 text-sm">
                    New sellers needing foundational support with listings, basic inventory tracking, and store setup.
                  </p>
                </div>
                
                <div>
                  <h4 className="text-white font-semibold mb-2">Growth</h4>
                  <p className="text-foreground/70 text-sm">
                    Established sellers optimizing operations, expanding platforms, implementing systematic processes.
                  </p>
                </div>
                
                <div>
                  <h4 className="text-white font-semibold mb-2">Full Support</h4>
                  <p className="text-foreground/70 text-sm">
                    Comprehensive operational management for busy sellers wanting a trusted partner handling all day-to-day operations.
                  </p>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <button className="btn-primary">Schedule Your Free Consultation</button>
                <button className="btn-secondary">Contact Me</button>
              </div>
            </div>

            <div className="bg-background rounded-lg p-8 border border-border h-full flex flex-col justify-center">
              <h3 className="text-primary font-serif text-2xl mb-4">Get Started Today</h3>
              <p className="text-foreground/70 mb-6">
                Schedule your free consultation and tell me about your business. I'll respond within 24 hours with thoughts on how I can help.
              </p>
              
              <div className="space-y-4">
                <input 
                  type="text" 
                  placeholder="Your Name" 
                  className="w-full px-4 py-3 bg-secondary border border-border rounded-md text-foreground placeholder:text-foreground/50 focus:outline-none focus:border-primary transition-colors"
                />
                <input 
                  type="email" 
                  placeholder="Your Email" 
                  className="w-full px-4 py-3 bg-secondary border border-border rounded-md text-foreground placeholder:text-foreground/50 focus:outline-none focus:border-primary transition-colors"
                />
                <textarea 
                  placeholder="Tell me about your business..." 
                  rows={4}
                  className="w-full px-4 py-3 bg-secondary border border-border rounded-md text-foreground placeholder:text-foreground/50 focus:outline-none focus:border-primary transition-colors"
                ></textarea>
                <button className="btn-primary w-full">Get Free Consultation</button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-background border-t border-border py-12">
        <div className="section-container">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="text-primary font-serif text-lg mb-4">E-Commerce Expert</h4>
              <p className="text-foreground/70 text-sm">
                Transforming chaotic e-commerce tasks into seamless, efficient operations.
              </p>
            </div>
            
            <div>
              <h4 className="text-white font-semibold mb-4">Services</h4>
              <ul className="space-y-2 text-sm text-foreground/70">
                <li><a href="#services" className="hover:text-primary transition-colors">Product Listings</a></li>
                <li><a href="#services" className="hover:text-primary transition-colors">Inventory Management</a></li>
                <li><a href="#services" className="hover:text-primary transition-colors">Customer Support</a></li>
                <li><a href="#services" className="hover:text-primary transition-colors">Store Admin</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-white font-semibold mb-4">Platforms</h4>
              <ul className="space-y-2 text-sm text-foreground/70">
                <li><a href="#platforms" className="hover:text-primary transition-colors">Shopify</a></li>
                <li><a href="#platforms" className="hover:text-primary transition-colors">eBay</a></li>
                <li><a href="#platforms" className="hover:text-primary transition-colors">Poshmark</a></li>
                <li><a href="#platforms" className="hover:text-primary transition-colors">WooCommerce</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-white font-semibold mb-4">Connect</h4>
              <ul className="space-y-2 text-sm text-foreground/70">
                <li><a href="#" className="hover:text-primary transition-colors">Email</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">LinkedIn</a></li>
                <li><a href="#" className="hover:text-primary transition-colors">Schedule Call</a></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-border pt-8 text-center text-foreground/50 text-sm">
            <p>&copy; 2024 E-Commerce Expert. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;
